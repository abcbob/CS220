/**
 * Removes all red color from an image
 * @param img An image
 * @returns A new image where each pixel has the red channel removed
 */
export function removeRed(img) {
    // TODO
    const newImage = img.copy();
    for (let x = 0; x < newImage.width; ++x)
        for (let y = 0; y < newImage.height; ++y) {
            const a = newImage.getPixel(x, y);
            newImage.setPixel(x, y, [0, a[1], a[2]]);
        }
    return newImage.copy();
}
/**
 * Flips the colors of an image
 * @param img An image
 * @returns A new image where each pixel's channel has been
 *  set as the truncated average of the other two
 */
export function flipColors(img) {
    // TODO
    for (let x = 0; x < img.width; ++x)
        for (let y = 0; y < img.height; ++y) {
            const a = img.getPixel(x, y);
            img.setPixel(x, y, [Math.floor((a[1] + a[2]) / 2), Math.floor((a[0] + a[2]) / 2), Math.floor((a[0] + a[1]) / 2)]);
        }
    return img.copy();
}
/**
 * Modifies the given `img` such that the value of each pixel
 * in the given line is the result of applying `func` to the
 * corresponding pixel of `img`. If `lineNo` is not a valid line
 * number, then `img` should not be modified.
 * @param img An image
 * @param lineNo A line number
 * @param func A color transformation function
 */
export function mapLine(img, lineNo, func) {
    // TODO
    if (lineNo > img.height || lineNo < 0)
        return;
    else {
        for (let x = 0; x < img.width; ++x) {
            const originalColor = img.getPixel(x, lineNo);
            const transformedColor = func(originalColor);
            img.setPixel(x, lineNo, transformedColor);
        }
    }
}
/**
 * The result must be a new image with the same dimensions as `img`.
 * The value of each pixel in the new image should be the result of
 * applying `func` to the corresponding pixel of `img`.
 * @param img An image
 * @param func A color transformation function
 */
export function imageMap(img, func) {
    const newImg = img.copy();
    for (let y = 0; y < img.height; ++y) {
        mapLine(newImg, y, func);
    }
    return newImg.copy();
}
/**
 * Removes all red color from an image
 * @param img An image
 * @returns A new image where each pixel has the red channel removed
 */
export function mapToGB(img) {
    function removeRedChannel(c) {
        return [0, c[1], c[2]];
    }
    const newImage = imageMap(img, removeRedChannel);
    return newImage.copy();
}
export function mapFlipColors(img) {
    function flipColor(color) {
        const new0 = Math.floor((color[1] + color[2]) / 2);
        const new1 = Math.floor((color[0] + color[2]) / 2);
        const new2 = Math.floor((color[0] + color[1]) / 2);
        return [new0, new1, new2];
    }
    const newImage = imageMap(img, flipColor);
    return newImage.copy();
}
//# sourceMappingURL=imageProcessing.js.map