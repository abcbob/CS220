import { Expression, Statement } from "../include/parser.js";

type RuntimeValue = number | boolean;
export type State = { [key: string]: State | RuntimeValue };

//const PARENT_STATE_KEY = "[[PARENT]]";

export function interpExpression(state: State, exp: Expression): RuntimeValue {
  // TODO
  switch (exp.kind) {
    case "boolean":
      return exp.value;
    case "number":
      return exp.value;
    case "variable":
      if (typeof state[exp.name] === "number" || typeof state[exp.name] === "boolean")
        return state[exp.name] as RuntimeValue;
      else throw new Error("wrong");
    case "operator": {
      const l = interpExpression(state, exp.left);
      const r = interpExpression(state, exp.right);
      if (typeof l === "number" && typeof r === "number")
        switch (exp.operator) {
          case "+":
            return l + r;
          case "-":
            return l - r;
          case "/":
            if (r === 0) throw new Error(`Invalid expression kind:`);
            else return l / r;
          case "*":
            return l * r;
          case "<":
            return l < r;
          case ">":
            return l > r;
          case "===":
            return l === r;
          default:
            throw new Error(`Invalid expression kind:`);
        }
      else if (typeof l === "boolean" || typeof r === "boolean")
        switch (exp.operator) {
          case "&&":
            return l && r;
          case "||":
            return l || r;
          case "===":
            return l === r;
          default:
            throw new Error(`Invalid expression kind: ${exp.kind}`);
        }
      else throw new Error(`Invalid expression kind: ${exp.kind}`);
    }
    default:
      throw new Error(`Invalid expression kind: ${exp.kind}`);
  }
}

export function interpStatement(state: State, stmt: Statement): void {
  // TODO
  switch (stmt.kind) {
    case "let": {
      if (stmt.name in state) throw new Error(`duplicate statement`);
      else {
        const v = interpExpression(state, stmt.expression);
        state[stmt.name] = v;
      }
      break;
    }
    case "assignment": {
      if (!(stmt.name in state)) throw new Error(`no variable`);
      else {
        const v = interpExpression(state, stmt.expression);
        state[stmt.name] = v;
      }
      break;
    }
    case "if": {
      const v = interpExpression(state, stmt.test);
      if (v && stmt.truePart.length !== 0) {
        const newState = Object.assign({}, state);
        stmt.truePart.forEach(statement => interpStatement(newState, statement));
      } else if (!v && stmt.truePart.length !== 0) {
        const newState = Object.assign({}, state);
        stmt.falsePart.forEach(statement => interpStatement(newState, statement));
      }
      break;
    }
    case "while": {
      let v = interpExpression(state, stmt.test);
      if (stmt.body.length === 0) {
        throw new Error("Infinite while loop found, terminating.");
      }
      const newState = state;
      while (v) {
        stmt.body.forEach(statement => interpStatement(newState, statement));
        v = interpExpression(newState, stmt.test);
      }
      break;
    }
    case "print": {
      console.log(interpExpression(state, stmt.expression));
    }
  }
  return;
}
export function interpProgram(program: Statement[]): State {
  // TODO
  const state: State = {};
  program.forEach(statement => interpStatement(state, statement));
  return state;
}
