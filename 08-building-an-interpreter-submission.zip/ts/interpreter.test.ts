import { parseExpression, parseProgram } from "../include/parser.js";
import { State, interpExpression, interpProgram, interpStatement } from "./interpreter.js";
import assert from "assert";
function expectStateToBe(program: string, state: State) {
  expect(interpProgram(parseProgram(program))).toEqual(state);
}

describe("interpExpression", () => {
  it("evaluates multiplication with a variable", () => {
    const r = interpExpression({ x: 10 }, parseExpression("x * 2"));

    expect(r).toBe(20);
  });
  it("evaluates multiplication with 2 variables", () => {
    const r = interpExpression({ x: 10, y: 20 }, parseExpression("x * y"));

    expect(r).toBe(200);
  });

  it("evaluates multiplication with 2 numbers", () => {
    const r = interpExpression({}, parseExpression("1 * 2"));
    expect(r).toEqual(2);
  });
  it("evaluates addition with 2 numbers", () => {
    const r = interpExpression({}, parseExpression("1 + 2"));
    expect(r).toEqual(3);
  });
  it("evaluates subtraction with 2 numbers", () => {
    const r = interpExpression({}, parseExpression("1 - 2"));
    expect(r).toEqual(-1);
  });
  it("evaluates division with 2 numbers", () => {
    const r = interpExpression({}, parseExpression("12 / 2 "));
    expect(r).toEqual(6);
  });
  it("rejects division with 2 numbers. right has 0", () => {
    expect(() => {
      interpExpression({}, parseExpression("12 / 0"));
    }).toThrow();
  });
  it("evaluates with 2 booleans", () => {
    const r = interpExpression({}, parseExpression("true && true "));
    expect(r).toEqual(true);
  });
  it("evaluates with comparisons", () => {
    const r = interpExpression({}, parseExpression("1 < 2 "));
    expect(r).toEqual(true);
    const s = interpExpression({}, parseExpression("1 > 2 "));
    expect(s).toEqual(false);
    const t = interpExpression({}, parseExpression("1 === 2 "));
    expect(t).toEqual(false);
  });
  it("evaluates logical arguments", () => {
    const r = interpExpression({}, parseExpression("true && false "));
    expect(r).toEqual(false);
    const s = interpExpression({}, parseExpression("true || true "));
    expect(s).toEqual(true);
    const t = interpExpression({}, parseExpression("true === true "));
    expect(t).toEqual(true);
    const z = interpExpression({}, parseExpression("12 && true "));
    expect(z).toEqual(true);
  });
  it("rejects a nonsense comparisons.", () => {
    expect(() => {
      interpExpression({}, parseExpression("1 && 2"));
    }).toThrow();
    expect(() => {
      interpExpression({}, parseExpression("true < true"));
    }).toThrow();
  });
});

describe("interpStatement", () => {
  it("can print expressions", () => {
    const logSpy = jest.spyOn(global.console, "log");

    const program = parseProgram(`
          print(1);
          print(1+2);
      `);
    interpStatement({}, program[0]);
    interpStatement({}, program[1]);
    expect(logSpy.mock.calls.sort()).toEqual([[1], [3]]);
  });
  test("assignment and let", () => {
    const st = interpProgram(parseProgram("let x = 10; x = 20 + 1;"));
    expect(st.x).toBe(21);
  });
  test("faulty assignment and let", () => {
    expect(() => {
      interpProgram(parseProgram("x = 10;"));
    }).toThrow();
    expect(() => {
      interpProgram(parseProgram("let x = 10; let x = 20;"));
    }).toThrow();
  });
  test("while works", () => {
    const w = interpProgram(parseProgram("let x = 25; while (x > 15) { x = 5; }"));
    assert(w.x === 5);
  });
  // Tests for interpStatement go here.
});

describe("interpProgram", () => {
  it("handles declarations and reassignment", () => {
    // TIP: Use the grave accent to define multiline strings
    expectStateToBe(
      `      
      let x = 10;
      x = 20;
    `,
      { x: 20 }
    );
  });
  it("test trivial if statement", function () {
    const z = interpProgram(parseProgram("let y = 20; if (y > 10) { } else { }"));
    assert(z.y === 20);
  });
  it("test if statement", function () {
    expectStateToBe(
      ` 
      if (false) {let y = 10;} else{ let y = 30; } 
    `,
      {}
    );
    expectStateToBe(
      ` 
      if (true) {let y = 10;} else{ let y = 30; } 
    `,
      {}
    );
  });
  it("test infinite while loop (should throw)", function () {
    expect(() => {
      interpProgram(parseProgram("let x = 25; while (x > 15) {  }"));
    }).toThrow();
  });
  it("test a complicated program:", () => {
    const prog = interpProgram(parseProgram("let x = 1; let sum = 0; while (x < 15) { sum = sum + x;  x = x + 1;}"));
    expect(prog.sum).toBe(105);
  });
});
