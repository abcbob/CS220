import { List, node, empty } from "../include/lists.js";

function nListHelper<T>(list: List<T>, inp: List<T>, cnt: number, n: number): List<T> {
  if (inp.isEmpty()) return list;
  if (cnt % n == 0) return node(inp.head(), nListHelper(list, inp.tail(), (cnt += 1), n));
  else return nListHelper(list, inp.tail(), (cnt += 1), n);
}
export function everyNList<T>(lst: List<T>, n: number): List<T> {
  return nListHelper(empty(), lst, 1, n);
}

export function everyNRev<T>(lst: List<T>, n: number): List<T> {
  let count = 1;
  const ans = lst.reduce((acc: List<T>, elem) => {
    if (count % n == 0) acc = node(elem, acc);
    count += 1;
    return acc;
  }, empty<T>());
  return ans;
}
export function everyNCond<T>(lst: List<T>, n: number, cond: (e: T) => boolean): List<T> {
  return everyNList(lst, n).filter(cond);
}
function productsHelper(lst: List<number>, sign: number): List<number> {
  let prev = 1;
  return lst
    .map(x => {
      if (sign * x > 0) {
        x = x * prev;
        prev = x;
      } else {
        prev = 1;
        x = 0;
      }
      return x;
    })
    .filter(x => x != 0);
}
export function nonNegativeProducts(lst: List<number>): List<number> {
  return productsHelper(lst, 1);
}

export function negativeProducts(lst: List<number>): List<number> {
  return productsHelper(lst, -1);
}

export function squashList(lst: List<number | List<number>>): List<number> {
  const reducer = (list: List<number>, x: number | List<number>) =>
    typeof x === "number"
      ? node(x, list)
      : node(
          x.reduce((acc, num) => acc + num, 0),
          list
        );
  return lst.foldRight(reducer, empty<number>());
}
export function composeList<T>(lst: List<(n: T) => T>): (n: T) => T {
  if (lst.isEmpty()) return (input: T) => input;
  else return (input: T) => composeList(lst.tail())(lst.head()(input));
}

export function composeFunctions<T, U>(funcArr: ((arg1: T, arg2: U) => T)[]): (a: U) => (x: T) => T {
  const applyRecursion = (funcs: ((arg1: T, arg2: U) => T)[], a: U, x: T): T => {
    if (funcs.length === 0) {
      return x;
    } else {
      const [firstFunc, ...restFuncs] = funcs;
      const intermediateResult = firstFunc(x, a);
      return applyRecursion(restFuncs, a, intermediateResult);
    }
  };

  return (a: U) => (x: T) => applyRecursion(funcArr, a, x);
}
