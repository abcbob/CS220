import { node, empty } from "../include/lists.js";
function nListHelper(list, inp, cnt, n) {
    if (inp.isEmpty())
        return list;
    if (cnt % n == 0)
        return node(inp.head(), nListHelper(list, inp.tail(), (cnt += 1), n));
    else
        return nListHelper(list, inp.tail(), (cnt += 1), n);
}
export function everyNList(lst, n) {
    return nListHelper(empty(), lst, 1, n);
}
export function everyNRev(lst, n) {
    let count = 1;
    const ans = lst.reduce((acc, elem) => {
        if (count % n == 0)
            acc = node(elem, acc);
        count += 1;
        return acc;
    }, empty());
    return ans;
}
export function everyNCond(lst, n, cond) {
    return everyNList(lst, n).filter(cond);
}
function productsHelper(lst, sign) {
    let prev = 1;
    return lst
        .map(x => {
        if (sign * x > 0) {
            x = x * prev;
            prev = x;
        }
        else {
            prev = 1;
            x = 0;
        }
        return x;
    })
        .filter(x => x != 0);
}
export function nonNegativeProducts(lst) {
    return productsHelper(lst, 1);
}
export function negativeProducts(lst) {
    return productsHelper(lst, -1);
}
export function squashList(lst) {
    const reducer = (list, x) => typeof x === "number"
        ? node(x, list)
        : node(x.reduce((acc, num) => acc + num, 0), list);
    return lst.foldRight(reducer, empty());
}
export function composeList(lst) {
    if (lst.isEmpty())
        return (input) => input;
    else
        return (input) => composeList(lst.tail())(lst.head()(input));
}
export function composeFunctions(funcArr) {
    const applyRecursion = (funcs, a, x) => {
        if (funcs.length === 0) {
            return x;
        }
        else {
            const [firstFunc, ...restFuncs] = funcs;
            const intermediateResult = firstFunc(x, a);
            return applyRecursion(restFuncs, a, intermediateResult);
        }
    };
    return (a) => (x) => applyRecursion(funcArr, a, x);
}
//# sourceMappingURL=lists.js.map