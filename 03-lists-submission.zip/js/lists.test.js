import assert from "assert";
import { node, empty, arrayToList, listToArray } from "../include/lists.js";
import { everyNList, everyNRev, everyNCond, nonNegativeProducts, negativeProducts, squashList, composeList, composeFunctions, } from "./lists.js";
describe("everyNList", () => {
    // Tests for everyNList go here
    it("should return a right answer", () => {
        const test = arrayToList([1, 2, 3, 4, 5, 6, 7, 8]);
        const output = listToArray(everyNList(test, 2));
        const ans = [2, 4, 6, 8];
        assert(JSON.stringify(ans) == JSON.stringify(output));
    });
});
describe("everyNRev", () => {
    // Tests for everyNRev go here
    it("should return a right answer", () => {
        const test = arrayToList([1, 2, 3, 4]);
        const output = listToArray(everyNRev(test, 2));
        const ans = [4, 2];
        console.log(output);
        assert(JSON.stringify(ans) == JSON.stringify(output));
    });
});
describe("everyNCond", () => {
    // Tests for everyNCond go here
    it("should return a right answer", () => {
        const test = arrayToList([1, 2, 3, 4, 5, 6, 7, 8, 9]);
        const output = listToArray(everyNCond(test, 2, x => x > 4));
        const ans = [6, 8];
        //console.log(output);
        assert(JSON.stringify(ans) == JSON.stringify(output));
    });
});
describe("nonNegativeProducts", () => {
    // Tests for nonNegativeProducts go here
    it("should return a right answer", () => {
        const test = arrayToList([2, 3, -1, 0.5, 2]);
        const output = listToArray(nonNegativeProducts(test));
        const ans = [2, 6, 0.5, 1];
        assert(JSON.stringify(ans) == JSON.stringify(output));
    });
});
describe("negativeProducts", () => {
    // Tests for nonNegativeProducts go here
    it("should return a right answer", () => {
        const test = arrayToList([-3, -6, 2, -2, -1, -2]);
        const output = listToArray(negativeProducts(test));
        const ans = [-3, 18, -2, 2, -4];
        assert(JSON.stringify(ans) === JSON.stringify(output));
    });
});
describe("squashList", () => {
    it("should return a right answer", () => {
        const test = node(node(9, node(10, empty())), empty());
        const output = listToArray(squashList(test));
        const ans = [19];
        assert(JSON.stringify(ans) === JSON.stringify(output));
    });
    // Tests for squashList go here
});
describe("composeList", () => {
    it("should return a right answer", () => {
        const addOne = (x) => x + 1;
        const double = (x) => x * 2;
        const subtractThree = (x) => x - 3;
        const functionsList = node(addOne, node(double, node(subtractThree, empty())));
        const composedFunction = composeList(functionsList);
        const output = composedFunction(5);
        assert(JSON.stringify(9) === JSON.stringify(output));
    });
});
describe("composeFunction", () => {
    // Tests for composeFunction go here
    it("should return a right answer", () => {
        const addA = (x, y) => x + y;
        const mulA = (x, y) => x * y;
        const subA = (x, y) => x - y;
        const functionsArray = [addA, mulA, subA];
        const closure = composeFunctions(functionsArray);
        const resultFunction = closure(5);
        const output = resultFunction(10);
        assert(output == 70);
    });
});
//# sourceMappingURL=lists.test.js.map