import type { Business } from "../include/data.js";
function ensureNumber(inp: number | undefined): number {
  if (typeof inp === "number") {
    return inp;
  } else {
    return -1;
  }
}
function cmpBusiness(a: Business, b: Business): number {
  if (ensureNumber(a.stars) < ensureNumber(b.stars)) return 1;
  else if (
    ensureNumber(a.stars) === ensureNumber(b.stars) &&
    ensureNumber(a.review_count) < ensureNumber(b.review_count)
  )
    return 1;
  return -1;
}
function cmpReviews(a: Business, b: Business): number {
  if (ensureNumber(a.review_count) > ensureNumber(b.review_count)) return 1;
  else if (
    ensureNumber(a.review_count) === ensureNumber(b.review_count) &&
    ensureNumber(a.stars) > ensureNumber(b.stars)
  )
    return 1;
  return -1;
}
export class FluentBusinesses {
  private data: Business[];

  constructor(data: Business[]) {
    this.data = data;
  }

  getData(): Business[] {
    return this.data;
  }

  fromCityInState(city: string, state: string): FluentBusinesses {
    const a = new FluentBusinesses(this.getData().filter(x => x.city === city && x.state === state));
    return a;
  }
  hasStarsGeq(stars: number): FluentBusinesses {
    // TODO
    return new FluentBusinesses(
      this.getData().filter(x => {
        const tmp = ensureNumber(x.stars);
        return tmp >= stars ? true : false;
      })
    );
  }

  inCategory(category: string): FluentBusinesses {
    // TODO
    const out = new FluentBusinesses(this.getData().filter(x => x.categories?.some(e => e === category)));
    return out;
  }

  hasHoursOnDays(days: string[]): FluentBusinesses {
    // TODO
    return new FluentBusinesses(this.getData().filter(x => days.every(e => x.hours != undefined && x.hours[e])));
  }

  hasAmbience(ambience: string): FluentBusinesses {
    // TODO
    return new FluentBusinesses(
      this.getData().filter(x => x.attributes?.Ambience != undefined && x.attributes.Ambience[ambience])
    );
  }

  bestPlace(): Business | undefined {
    // TODO
    if (this.getData().length === 0) return undefined;
    const out = this.getData().sort((a, b) => cmpBusiness(a, b));
    return out[0];
  }

  mostReviews(): Business | undefined {
    // TODO
    if (this.getData().length === 0) return undefined;
    const out = this.getData().sort((a, b) => cmpReviews(a, b));
    return out[0];
  }
}
