function ensureNumber(inp) {
    if (typeof inp === "number") {
        return inp;
    }
    else {
        return -1;
    }
}
function cmpBusiness(a, b) {
    if (ensureNumber(a.stars) < ensureNumber(b.stars))
        return 1;
    else if (ensureNumber(a.stars) === ensureNumber(b.stars) &&
        ensureNumber(a.review_count) < ensureNumber(b.review_count))
        return 1;
    return -1;
}
function cmpReviews(a, b) {
    if (ensureNumber(a.review_count) > ensureNumber(b.review_count))
        return 1;
    else if (ensureNumber(a.review_count) === ensureNumber(b.review_count) &&
        ensureNumber(a.stars) > ensureNumber(b.stars))
        return 1;
    return -1;
}
export class FluentBusinesses {
    data;
    constructor(data) {
        this.data = data;
    }
    getData() {
        return this.data;
    }
    fromCityInState(city, state) {
        const a = new FluentBusinesses(this.getData().filter(x => x.city === city && x.state === state));
        return a;
    }
    hasStarsGeq(stars) {
        // TODO
        return new FluentBusinesses(this.getData().filter(x => {
            const tmp = ensureNumber(x.stars);
            return tmp >= stars ? true : false;
        }));
    }
    inCategory(category) {
        // TODO
        const out = new FluentBusinesses(this.getData().filter(x => x.categories?.some(e => e === category)));
        return out;
    }
    hasHoursOnDays(days) {
        // TODO
        return new FluentBusinesses(this.getData().filter(x => days.every(e => x.hours != undefined && x.hours[e])));
    }
    hasAmbience(ambience) {
        // TODO
        return new FluentBusinesses(this.getData().filter(x => x.attributes?.Ambience != undefined && x.attributes.Ambience[ambience]));
    }
    bestPlace() {
        // TODO
        if (this.getData().length === 0)
            return undefined;
        const out = this.getData().sort((a, b) => cmpBusiness(a, b));
        return out[0];
    }
    mostReviews() {
        // TODO
        if (this.getData().length === 0)
            return undefined;
        const out = this.getData().sort((a, b) => cmpReviews(a, b));
        return out[0];
    }
}
//# sourceMappingURL=FluentBusinesses.js.map