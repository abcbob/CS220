import { snode } from "../include/stream.js";
// In Class Exercises
/**
 * EXCERCISE 1
 *
 * Create an infinite tream of non-negative integers that are multiples of 3. Do not use higher-order-functions.
 *
 */
export function every3_1(n) {
    // TODO: Implement this function
    function every3(n) {
        return snode(n, () => every3(n + 3));
    }
    const mult3stream = every3(0);
    return mult3stream;
}
/**
 * EXCERCISE 2
 *
 * Write a function that takes as arguments a stream of numbers and returns a stream of those numbers which are
 * multiples of their predicessor in the original stream.
 *
 */
export function keepMult_1(s) {
    // TODO: Implement this function
    let prev;
    const a = s.filter(elem => {
        const f = elem % prev === 0;
        prev = elem;
        return f;
    });
    return a;
}
/**
 * EXCERCISE 3
 *
 * Write a function that takes two streams (finite or infinite) and returns a single stream which interleaves
 * the values from each of the inputs.
 *
 */
export function interStream(s1, s2) {
    // TODO: Implement this function
    return s1.isEmpty() ? s2 : snode(s1.head(), () => interStream(s2, s1.tail()));
}
//# sourceMappingURL=lab.js.map