import assert from "assert";
import { Hire, Offer } from "../include/stableMatching.js";

import type { StableMatcher, StableMatcherWithTrace } from "../include/stableMatching.js";

function shuffle(inp: number[]): number[] {
  const arr = inp;
  for (let i = arr.length - 1; i >= 1; --i) {
    const j = randomInt(0, i + 1);
    const temp = arr[i];
    arr[i] = arr[j];
    arr[j] = temp;
  }
  return arr;
}
function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min)) + min;
}
export function generateInput(n: number): number[][] {
  // TODO
  const out: number[][] = [];
  let elem: number[] = [];
  for (let i = 0; i < n; ++i) {
    for (let i = 0; i < n; ++i) elem[i] = i;
    elem = shuffle(elem);
    out.push(elem);
  }
  return out;
}

const NUM_TESTS = 1; // Change this to some reasonably large value
const N = 3; // Change this to some reasonable size

function isValidMatching(matching: Hire[], companies: number[][], candidates: number[][]): boolean {
  // Implement to check if the matching is valid
  // Compare the matching against the expected matching
  // Return true if it's valid, false otherwise
  function findMatchingCandidate(m: Hire[], x: number): number {
    for (const hire of m) if (hire.company === x) return hire.candidate;
    return -1;
  }
  return matching.every(elem => {
    const companyPrefs = companies[elem.company];
    const candidatePrefs = candidates[elem.candidate];
    const companyRank = candidatePrefs.indexOf(elem.company);
    for (let i = 0; i < companyRank; i++) {
      const preferredCompany = candidatePrefs[i];
      const currentMatchRank = companies[preferredCompany].indexOf(findMatchingCandidate(matching, preferredCompany));
      const proposedMatchRank = companyPrefs.indexOf(elem.candidate);
      if (currentMatchRank > proposedMatchRank || currentMatchRank == -1) return false;
    }
    return true;
  });
}
/**
 * Tests whether or not the supplied function is a solution to the stable matching problem.
 * @param makeStableMatching A possible solution to the stable matching problem
 * @throws An `AssertionError` if `makeStableMatching` in not a solution to the stable matching problem
 */
export function stableMatchingOracle(makeStableMatching: StableMatcher): void {
  for (let i = 0; i < NUM_TESTS; ++i) {
    const companies = generateInput(N);
    const candidates = generateInput(N);
    const hires = makeStableMatching(companies, candidates);
    assert(companies.length === hires.length, "Hires length correct.");
    assert(companies.length > 0, "eligible size");
    assert(isValidMatching(hires, companies, candidates), "Matching is stable.");
    // TODO: More assertions go here.
  }
}

// Part B

/**
 * Tests whether or not the supplied function follows the supplied algorithm.
 * @param makeStableMatchingTrace A possible solution to the stable matching problem and its possible steps
 * @throws An `AssertionError` if `makeStableMatchingTrace` does not follow the specified algorithm, or its steps (trace)
 * do not match with the result (out).
 */
export function stableMatchingRunOracle(makeStableMatchingTrace: StableMatcherWithTrace): void {
  for (let i = 0; i < NUM_TESTS; ++i) {
    const companies = generateInput(N);
    const candidates = generateInput(N);
    const { trace, out } = makeStableMatchingTrace(companies, candidates);
    console.log(companies);
    console.log(candidates);
    assert(companies.length === candidates.length, "Hires length correct.");
    assert(companies.length > 0, "eligible size");
    assert(traceStableMatching(trace, companies, candidates), "true");
    if (out.length === companies.length) assert(isValidMatching(out, companies, candidates), "Is stable matching");
    // This statement is here to prevent linter warnings about `trace` and `out` not being used.
    // Remove it as necessary.
    console.log(trace, out);

    // TODO: Assertions go here
  }
  function traceStableMatching(o: Offer[], companies: number[][], candidates: number[][]): boolean {
    function findMatchingCandidate(from: number, to: number): number {
      for (let j = 0; j < companies[from].length; ++j) if (companies[from][j] === to) return j;
      return -1;
    }
    function findMatchingCompany(from: number, to: number): number {
      for (let j = 0; j < candidates[from].length; ++j) if (candidates[from][j] === to) return j;
      return -1;
    }
    const companyMatch: number[] = [];
    for (let i = 0; i < companies.length; ++i) companyMatch.push(-1);
    const candidateMatch: number[] = [];
    for (let i = 0; i < candidates.length; ++i) candidateMatch.push(-1);
    const companyOfferOrder = new Array(companies.length).fill(-1);
    const candidateOfferOrder = new Array(candidates.length).fill(-1);
    return o.every(element => {
      if (element.fromCo)
        if (companyMatch[element.from] === -1 && candidateMatch[element.to] === -1) {
          companyMatch[element.from] = element.to;
          candidateMatch[element.to] = element.from;
          companyOfferOrder[element.from] = findMatchingCandidate(element.from, element.to);
          return true;
        } else if (companyMatch[element.from] != -1) return false;
        else if (candidateMatch[element.to] != -1) {
          if (
            findMatchingCompany(element.to, candidateMatch[element.to]) > findMatchingCompany(element.to, element.from)
          ) {
            companyMatch[candidateMatch[element.to]] = -1;
            companyMatch[element.from] = element.to;
            candidateMatch[element.to] = element.from;
            companyOfferOrder[element.from] = findMatchingCandidate(element.from, element.to);
            return true;
          } else return false;
        } else if (candidateMatch[element.from] === -1 && companyMatch[element.to] === -1) {
          candidateMatch[element.from] = element.to;
          companyMatch[element.to] = element.from;
          candidateOfferOrder[element.from] = findMatchingCandidate(element.from, element.to);
          return true;
        } else if (candidateMatch[element.from] != -1) return false;
        else if (companyMatch[element.to] != -1) {
          if (
            findMatchingCandidate(element.to, companyMatch[element.to]) >
            findMatchingCandidate(element.to, element.from)
          ) {
            candidateMatch[companyMatch[element.to]] = -1;
            candidateMatch[element.from] = element.to;
            companyMatch[element.to] = element.from;
            candidateOfferOrder[element.from] = findMatchingCompany(element.from, element.to);
            return true;
          } else return false;
        }
      return false;
    });
  }
}
