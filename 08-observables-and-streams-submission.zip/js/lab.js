import { Observable } from "../include/observable.js";
import { snode, sempty } from "../include/stream.js";
export class Economy extends Observable {
    updateRate(rate) {
        // TODO: Implement this method
        this.update(rate);
    }
}
export class Stock extends Observable {
    name;
    base;
    price;
    constructor(name, base, price) {
        super();
        this.name = name;
        this.base = base;
        this.price = price;
        // TODO: Implement the constructor
    }
    updatePrice(rate) {
        // TODO: Implement this method
        this.price = this.base * rate;
        this.update(this.price);
    }
}
//  Should observe and report Stock's price
export class Newscast extends Observable {
    constructor() {
        super();
        // TODO: Implement the constructor
    }
    report(name, price) {
        console.log(`Stock ${name} has price ${price}.`);
        this.update([name, price]);
    }
    observe(...stocks) {
        // TODO: Implement this method
        stocks.forEach(stock => stock.subscribe(price => this.report(stock.name, price)));
    }
}
const USEconomy = new Economy();
const stock = new Stock("GME", 5.0, 1.0);
const news = new Newscast();
USEconomy.subscribe(rate => stock.updatePrice(rate));
stock.subscribe(price => news.report("GME", price));
USEconomy.updateRate(5); // “Stock GME has price 5.”
USEconomy.updateRate(1); // “Stock GME has price 1.”
export function maxUpTo(s) {
    // TODO: Implement this method
    let m = -1;
    function helper(stream) {
        if (stream.isEmpty())
            return sempty();
        m = Math.max(stream.head(), m);
        return snode(m, () => helper(stream.tail()));
    }
    return helper(s);
}
//# sourceMappingURL=lab.js.map