import { Observable } from "../include/observable.js";
import { snode, Stream, sempty } from "../include/stream.js";

export class Economy extends Observable<number> {
  updateRate(rate: number): void {
    // TODO: Implement this method
    this.update(rate);
  }
}

export class Stock extends Observable<number> {
  name: string;
  base: number;
  price: number;
  constructor(name: string, base: number, price: number) {
    super();
    this.name = name;
    this.base = base;
    this.price = price;
    // TODO: Implement the constructor
  }

  updatePrice(rate: number): void {
    // TODO: Implement this method
    this.price = this.base * rate;
    this.update(this.price);
  }
}

//  Should observe and report Stock's price
export class Newscast extends Observable<[string, number]> {
  constructor() {
    super();
    // TODO: Implement the constructor
  }

  report(name: string, price: number): void {
    console.log(`Stock ${name} has price ${price}.`);
    this.update([name, price]);
  }

  observe(...stocks: Stock[]): void {
    // TODO: Implement this method
    stocks.forEach(stock => stock.subscribe(price => this.report(stock.name, price)));
  }
}

const USEconomy = new Economy();
const stock = new Stock("GME", 5.0, 1.0);
const news = new Newscast();

USEconomy.subscribe(rate => stock.updatePrice(rate));
stock.subscribe(price => news.report("GME", price));

USEconomy.updateRate(5); // “Stock GME has price 5.”
USEconomy.updateRate(1); // “Stock GME has price 1.”

export function maxUpTo(s: Stream<number>): Stream<number> {
  // TODO: Implement this method
  let m = -1;
  function helper(stream: Stream<number>): Stream<number> {
    if (stream.isEmpty()) return sempty();
    m = Math.max(stream.head(), m);
    return snode(m, () => helper(stream.tail()));
  }
  return helper(s);
}
