import { Stream, to } from "../include/stream.js";
import {
  addSeries,
  prodSeries,
  derivSeries,
  coeff,
  evalSeries,
  applySeries,
  expSeries,
  recurSeries,
} from "./series.js";

function expectStreamToBe<T>(s: Stream<T>, a: T[]) {
  for (const element of a) {
    expect(s.isEmpty()).toBe(false);
    expect(s.head()).toBe(element);

    s = s.tail();
  }

  expect(s.isEmpty()).toBe(true);
}

describe("addSeries", () => {
  it("adds 2 empty streams together", () => {
    // Open `include/stream.ts` to learn how to use `to`
    // 1 -> 2 -> 3 -> 4 -> 5
    const a = to(1, 0);
    const b = to(1, 0);
    const c = addSeries(a, b);

    expectStreamToBe(c, []);
  });
  it("adds streams with an empty stream together", () => {
    // Open `include/stream.ts` to learn how to use `to`
    // 1 -> 2 -> 3 -> 4 -> 5
    const a = to(1, 5);
    const b = to(1, 0);
    const c = addSeries(a, b);

    expectStreamToBe(c, [1, 2, 3, 4, 5]);
  });
  it("adds different coefficient streams together", () => {
    // Open `include/stream.ts` to learn how to use `to`
    // 1 -> 2 -> 3 -> 4 -> 5
    const a = to(1, 5);
    const b = to(1, 3);
    const c = addSeries(a, b);

    expectStreamToBe(c, [2, 4, 6, 4, 5]);
  });
  it("adds simple streams together", () => {
    // Open `include/stream.ts` to learn how to use `to`
    // 1 -> 2 -> 3 -> 4 -> 5
    const a = to(1, 5);
    const b = to(1, 5);
    const c = addSeries(a, b);

    expectStreamToBe(c, [2, 4, 6, 8, 10]);
  });
});

describe("prodSeries", () => {
  // More tests for prodSeries go here
  it("multiplies empty stream with an empty stream together", () => {
    // Open `include/stream.ts` to learn how to use `to`
    // 1 -> 2 -> 3 -> 4 -> 5
    const a = to(1, 0);
    const b = to(1, 0);
    const c = prodSeries(a, b);
    expectStreamToBe(c, []);
  });
  it("multiplies simple stream with an empty stream together", () => {
    // Open `include/stream.ts` to learn how to use `to`
    // 1 -> 2 -> 3 -> 4 -> 5
    const a = to(1, 2);
    const b = to(1, 0);
    const c = prodSeries(a, b);
    expectStreamToBe(c, []);
  });
  it("multiplies simple streams together", () => {
    // Open `include/stream.ts` to learn how to use `to`
    // 1 -> 2 -> 3 -> 4 -> 5
    const a = to(1, 2);
    const b = to(1, 2);
    const c = prodSeries(a, b);
    expectStreamToBe(c, [1, 4, 4]);
  });
});

describe("derivSeries", () => {
  // More tests for derivSeries go here
  it("deriviate a stream", () => {
    // Open `include/stream.ts` to learn how to use `to`
    // 1 -> 2 -> 3 -> 4 -> 5
    const a = to(1, 5);
    const c = derivSeries(a);
    expectStreamToBe(c, [2, 6, 12, 20]);
  });
  it("deriviate an empty stream", () => {
    // Open `include/stream.ts` to learn how to use `to`
    // 1 -> 2 -> 3 -> 4 -> 5
    const a = to(1, 0);
    const c = derivSeries(a);
    expectStreamToBe(c, []);
  });
  it("deriviate a stream with 1 coefficient", () => {
    // Open `include/stream.ts` to learn how to use `to`
    // 1 -> 2 -> 3 -> 4 -> 5
    const a = to(1, 1);
    const c = derivSeries(a);
    expectStreamToBe(c, []);
  });
});

describe("coeff", () => {
  // More tests for coeff go here
  it("return no coefficient", () => {
    // Open `include/stream.ts` to learn how to use `to`
    // 1 -> 2 -> 3 -> 4 -> 5
    const a = to(1, 0);
    const c = coeff(a, 0);
    expect(JSON.stringify(c)).toBe(JSON.stringify([]));
  });
  it("return coefficient 0", () => {
    // Open `include/stream.ts` to learn how to use `to`
    // 1 -> 2 -> 3 -> 4 -> 5
    const a = to(1, 5);
    const c = coeff(a, 0);
    expect(JSON.stringify(c)).toBe(JSON.stringify([1]));
  });
  it("return an array of coefficient less than the stream", () => {
    // Open `include/stream.ts` to learn how to use `to`
    // 1 -> 2 -> 3 -> 4 -> 5
    const a = to(1, 5);
    const c = coeff(a, 3);
    expect(JSON.stringify(c)).toBe(JSON.stringify([1, 2, 3, 4]));
  });
  it("return an array of coefficient", () => {
    // Open `include/stream.ts` to learn how to use `to`
    // 1 -> 2 -> 3 -> 4 -> 5
    const a = to(1, 5);
    const c = coeff(a, 5);
    expect(JSON.stringify(c)).toBe(JSON.stringify([1, 2, 3, 4, 5]));
  });
});

describe("evalSeries", () => {
  // More tests for evalSeries go here
  it("return an sum less than the stream", () => {
    // Open `include/stream.ts` to learn how to use `to`
    // 1 -> 2 -> 3 -> 4 -> 5
    const a = to(1, 5);
    const c = evalSeries(a, 3);
    expect(c(1)).toBe(10);
  });
  it("return a sum", () => {
    // Open `include/stream.ts` to learn how to use `to`
    // 1 -> 2 -> 3 -> 4 -> 5
    const a = to(1, 5);
    const c = evalSeries(a, 5);
    expect(c(1)).toBe(15);
  });
});

describe("applySeries", () => {
  // More tests for applySeries go here
  it("return a series", () => {
    const f = (x: number) => x + 1;
    const ans = applySeries(f, 1);
    expect(ans.head()).toBe(1);
  });
});

describe("expSeries", () => {
  // More tests for expSeries go here
  it("return a infinite series", () => {
    const ans = expSeries();
    expect(ans.head()).toBe(1);
    expect(ans.tail().head()).toBe(1);
    expect(ans.tail().tail().head()).toBe(1 / 2);
  });
});

describe("recurSeries", () => {
  // More tests for recurSeries go here
  it("return a infinite series of 1", () => {
    const ans = recurSeries([1], [1]);
    expect(ans.head()).toBe(1);
    expect(ans.tail().head()).toBe(1);
    expect(ans.tail().tail().head()).toBe(1);
    expect(ans.tail().tail().tail().head()).toBe(1);
  });
  it("return a infinite series", () => {
    const ans = recurSeries([1, 2, 3], [1, 2, 3]);
    expect(ans.head()).toBe(1);
    expect(ans.tail().head()).toBe(2);
    expect(ans.tail().tail().head()).toBe(3);
    expect(ans.tail().tail().tail().head()).toBe(14);
  });
});
