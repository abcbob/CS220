import { sempty, Stream, snode } from "../include/stream.js";

export type Series = Stream<number>;

export function addSeries(s: Series, t: Series): Series {
  // TODO
  if (s.isEmpty()) return t;
  if (t.isEmpty()) return s;
  return snode(s.head() + t.head(), () => addSeries(s.tail(), t.tail()));
}
export function prodSeries(s: Series, t: Series): Series {
  // TODO
  if (s.isEmpty() || t.isEmpty()) return sempty();
  function seriesMultNum(x: number, ser: Series): Series {
    if (ser.isEmpty()) return sempty();
    else return snode(x * ser.head(), () => seriesMultNum(x, ser.tail()));
  }
  return snode(s.head() * t.head(), () => addSeries(prodSeries(s.tail(), t), seriesMultNum(s.head(), t.tail())));
}
export function derivSeries(s: Series): Series {
  // TODO
  let o = 0;
  if (s.isEmpty()) return s;
  function helper(streams: Series): Series {
    if (streams.isEmpty()) return streams;
    o += 1;
    return snode(streams.head() * o, () => helper(streams.tail()));
  }
  return helper(s.tail());
}

export function coeff(s: Series, n: number): number[] {
  // TODO
  const a: number[] = [];
  let tmp = s;
  if (s.isEmpty()) return [];
  else
    for (let i = 0; i <= n; ++i) {
      if (tmp.isEmpty()) return a;
      a.push(tmp.head());
      tmp = tmp.tail();
    }
  return a;
}

export function evalSeries(s: Series, n: number): (x: number) => number {
  // TODO
  const a = coeff(s, n + 1);
  return function (x) {
    let result = 0;
    for (let i = 0; i < Math.min(a.length, n + 1); i++) {
      result += a[i] * Math.pow(x, i);
    }
    return result;
  };
}

export function applySeries(f: (c: number) => number, v: number): Series {
  // TODO
  return snode(v, () => applySeries(f, f(v)));
}

export function expSeries(): Series {
  // TODO
  function sfact(prev: number, n: number): Stream<number> {
    return snode((prev /= n), () => sfact(prev, n + 1));
  }
  return snode(1, () => sfact(1, 1));
}

export function recurSeries(coef: number[], init: number[]): Series {
  // TODO
  if (coef.length === 0) return sempty();
  function recurHelper(cnt: number, prev: number[]): Series {
    if (cnt < coef.length) return snode(init[cnt], () => recurHelper(cnt + 1, init));
    else {
      let ans = 0;
      for (let i = 0; i < prev.length; ++i) ans += prev[i] * coef[i];
      prev.slice(1, prev.length - 1).push(1);
      return snode(ans, () => recurHelper(cnt + 1, prev));
    }
  }
  return recurHelper(0, init);
}
