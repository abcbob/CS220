// Reduce Review
// Sample Reduce Implementation
function reduce(a, f, init) {
    let result = init;
    for (let i = 0; i < a.length; ++i) {
        result = f(result, a[i]);
    }
    return result;
}
// Example:
const arr = [3, 2, 6, 2, 2, 0];
const result = reduce(arr, (prod, e) => prod * e, 1);
// Alternatively: arr.reduce((prod, e) => prod * e, 1);
console.log(result);
// In class exercises
export function mainlyBlue(arr) {
    // TODO: Implement this function
    const a = arr.filter(x => x[2] >= x[0] * 2 && x[2] >= x[1] * 2);
    const ans = a.reduce(prod => prod + 1, 0);
    return ans;
}
export function mainlyBlue2D(arr) {
    // TODO: Implement this function
    let ans = 0;
    for (let i = 0; i < arr.length; i++)
        ans = ans + mainlyBlue(arr[i]);
    return ans;
}
export function sumLog(nums) {
    // TODO: Implement this function
    const ans = nums.filter(x => x > 0);
    return ans.reduce((prod, e) => prod + Math.log(e), 0);
}
//# sourceMappingURL=lab.js.map