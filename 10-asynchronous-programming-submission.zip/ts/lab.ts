import fetch from "../include/fetch";

/**
 * Exercise 1
 */

export type ObjsWithName = { name: string; [key: string]: unknown };
/*const a:Promise<number> = new Promise<number>(()=>4);
const c= a.then(n=>n++).then(b=>b--);
const b = await a;*/

export function getObjsWithName(urls: string[]): Promise<ObjsWithName[]> {
  return Promise.allSettled(urls.map((url: string) => fetch(url).then(res => res.json()))).then(resarr =>
    resarr
      .filter((resarr): resarr is PromiseFulfilledResult<(Object | ObjsWithName)[]> => resarr.status === "fulfilled")
      .map(resarr => resarr["value"])
      .map(objarr => objarr.filter(obj => "name" in obj) as ObjsWithName[])
      .flat()
  );
}

// Lets try using our function!
const urls: string[] = [
  "https://api.github.com/users/umass-compsci-220/repos",
  "https://api.github.com/users/umass-cs-230/repos",
];

getObjsWithName(urls)
  .then(obs => obs.map(obj => obj["name"]))
  .then(console.log)
  .catch(console.log);

/**
 * Exercise 2
 */

// composeFunctionsAsync
export function composeFunctionsAsync<T>(asyncFuncArr: ((a: any) => Promise<any>)[]): (a: T) => Promise<any> {
  return (x: any) => {
    return asyncFuncArr.reduce((acc: Promise<any>, f: (a: any) => Promise<any>) => acc.then(f), Promise.resolve(x));
  };
  //return (a: T) => Promise.resolve();
}

const getjson = composeFunctionsAsync([
  fetch,
  (res: Response) => (res.ok ? res.json() : Promise.reject(`${res.status} : ${res.statusText}`)),
]);

/* test async function composition */
getjson("https://api.github.com/users/umass-cs-230/repos")
  .then(res => res[0]["owner"])
  .then(console.log)
  .catch(console.log);
