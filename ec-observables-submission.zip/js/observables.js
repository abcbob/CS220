import { Observable } from "../include/observable.js";
// Extra Credit Functions
export function classifyObservables(obsArr) {
    // TODO: Implement this function
    const outStr = new Observable();
    const outNum = new Observable();
    const outBoo = new Observable();
    obsArr.forEach(x => {
        x.subscribe(value => {
            if (typeof value === "string")
                outStr.update(value);
            if (typeof value === "number")
                outNum.update(value);
            if (typeof value === "boolean")
                outBoo.update(value);
        });
    });
    return { string: outStr, number: outNum, boolean: outBoo };
}
export function obsStrCond(funcArr, f, o) {
    // TODO: Implement this function
    const r = new Observable();
    o.subscribe(x => {
        let out = x;
        for (const f of funcArr)
            out = f(out);
        if (f(out))
            r.update(out);
        else
            r.update(x);
    });
    return r;
}
export function statefulObserver(o) {
    // TODO: Implement this function
    let prev = 0;
    const r = new Observable();
    o.subscribe(v => {
        if (v % prev === 0) {
            r.update(v);
        }
        prev = v;
    });
    return r;
}
// Optional Additional Practice
export function mergeMax(o1, o2) {
    // TODO: Implement this function
    let prevMax = -Infinity;
    const r = new Observable();
    const f = (id) => (v) => {
        // f(id) is a closure receiving a value, possibly updating r
        if (v >= prevMax) {
            prevMax = v;
            r.update({ obs: id, v });
        }
    };
    o1.subscribe(f(1)); // closures subscribed to o1 and o2 are parameterized
    o2.subscribe(f(2)); // with ID of observable and share environment (prevMax)
    return r;
}
export function merge(o1, o2) {
    // TODO: Implement this function
    const r = new Observable();
    const merger = (e) => {
        r.update(e);
    };
    o1.subscribe(merger);
    o2.subscribe(merger);
    return r;
}
export class GreaterAvgObservable extends Observable {
    constructor() {
        super();
    }
    greaterAvg() {
        // TODO: Implement this method
        const r = new Observable();
        let prev = Infinity;
        let last = Infinity;
        this.subscribe(v => {
            if (v >= ((prev + last) * 3) / 4) {
                r.update(v);
            }
            prev = last;
            last = v;
        });
        return r;
    }
}
export class SignChangeObservable extends Observable {
    constructor() {
        super();
    }
    signChange() {
        // TODO: Implement this method
        const signChangeObservable = new Observable();
        let prevSign = 0;
        this.subscribe((value) => {
            if ((value > 0 && prevSign <= 0) || (value < 0 && prevSign >= 0)) {
                signChangeObservable.update(value);
            }
            prevSign = Math.sign(value);
        });
        return signChangeObservable;
    }
}
/**
 * This function shows how the class you created above could be used.
 * @param numArr Array of numbers
 * @param f Observer function
 */
export function usingSignChange(numArr, f) {
    // TODO: Implement this function
    const sourceObservable = new SignChangeObservable();
    const signChangeObservable = sourceObservable.signChange();
    signChangeObservable.subscribe(f);
    for (const num of numArr) {
        sourceObservable.update(num);
    }
}
//# sourceMappingURL=observables.js.map