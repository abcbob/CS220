//import assert from "assert";
import { Observable } from "../include/observable.js";
import {
  classifyObservables,
  obsStrCond,
  statefulObserver,
  merge,
  mergeMax,
  SignChangeObservable,
  GreaterAvgObservable,
} from "./observables.js";

describe("classifyObservables", () => {
  it("classifies a number observable", () => {
    const o = new Observable<number>();

    const { number } = classifyObservables([o]);
    const spy = jest.fn();
    number.subscribe(spy);

    o.update(1);
    expect(spy).toHaveBeenCalledTimes(1);
  });
  it("classifies a string observable", () => {
    const o = new Observable<string>();

    const { string } = classifyObservables([o]);
    const spy = jest.fn();
    string.subscribe(spy);

    o.update("abc");
    expect(spy).toHaveBeenCalledTimes(1);
  });
  it("classifies a boolean observable", () => {
    const o = new Observable<boolean>();

    const { boolean } = classifyObservables([o]);
    const spy = jest.fn();
    boolean.subscribe(spy);

    o.update(true);
    expect(spy).toHaveBeenCalledTimes(1);
  });
  // More tests go here.
  it("classifies observables", () => {
    const o = new Observable<string>();
    const o2 = new Observable<number>();
    const o3 = new Observable<boolean>();
    const { string } = classifyObservables([o, o2, o3]);
    const spy = jest.fn();
    string.subscribe(spy);

    o.update("abc");
    expect(spy).toHaveBeenCalledTimes(1);
  });
});

describe("obsStrCond", () => {
  // More tests go here.
  it("pass the condition", () => {
    const funcArr = [(str: string) => str.toUpperCase(), (str: string) => str.substring(0, 3)];

    const condition = (str: string) => str.length >= 5;

    const o = new Observable<string>();
    const arr: string[] = [];
    const spy = jest.fn((n: string) => arr.push(n));
    o.subscribe(spy);
    o.update("Hello");
    const resultObservable = obsStrCond(funcArr, condition, o);
    resultObservable.subscribe(spy);
    expect(arr).toEqual(["Hello"]);
    console.log(arr);
  });
});

describe("statefulObserver", () => {
  it("should update when the current value is divisible by the previous value", () => {
    const o = new Observable<number>();
    const updates: number[] = [];
    const spy1 = jest.fn((n: number) => updates.push(n));
    o.subscribe(spy1);
    o.update(1);
    o.update(2);
    o.update(3);
    o.update(6);
    o.update(12);
    o.update(15);
    expect(spy1).toHaveBeenCalledTimes(6);
    const r = statefulObserver(o);
    r.subscribe(spy1);
    expect(updates).toEqual([1, 2, 3, 6, 12, 15]);
  });
  // More tests go here.
});

describe("mergeMax", () => {
  // More tests go here.
  it("should mergeMax", () => {
    const o1 = new Observable<number>();
    const o2 = new Observable<number>();
    const o = mergeMax(o1, o2);
    expect(o).toEqual(o);
  });
});

describe("merge", () => {
  // More tests go here.
  it("should merge", () => {
    const o1 = new Observable<string>();
    const o2 = new Observable<string>();
    const arr = [];
    const spy1 = jest.fn((a: string) => arr.push(a));
    const spy2 = jest.fn((b: string) => arr.push(b));
    o1.subscribe(spy1);
    o2.subscribe(spy2);
    o1.update("A");
    o2.update("B");
    const o = merge(o1, o2);
    o.update("a");
    o.update("b");
    expect(spy1).toHaveBeenCalledTimes(1);
    expect(spy2).toHaveBeenCalledTimes(1);
  });
});

describe("GreaterAvgObservable", () => {
  // More tests go here.
  it("should work", () => {
    const o1 = new GreaterAvgObservable();
    const spy1 = jest.fn();
    o1.subscribe(spy1);
    o1.update(1);
    o1.greaterAvg();
  });
});

describe("SignChangeObservable", () => {
  // More tests go here.
  it("should work", () => {
    const o1 = new SignChangeObservable();
    const spy1 = jest.fn();
    o1.subscribe(spy1);
    o1.update(1);
    o1.signChange();
  });
});

describe("usingSignChange", () => {
  // More tests go here.
  it("should work", () => {
    const o1 = new SignChangeObservable();
    const spy1 = jest.fn();
    o1.subscribe(spy1);
    o1.update(1);
    o1.signChange();
  });
});
