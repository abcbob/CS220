import { Observable, Observer } from "../include/observable.js";

// Extra Credit Functions

export function classifyObservables(obsArr: (Observable<string> | Observable<number> | Observable<boolean>)[]): {
  string: Observable<string>;
  number: Observable<number>;
  boolean: Observable<boolean>;
} {
  // TODO: Implement this function

  const outStr: Observable<string> = new Observable();
  const outNum: Observable<number> = new Observable();
  const outBoo: Observable<boolean> = new Observable();
  obsArr.forEach(x => {
    x.subscribe(value => {
      if (typeof value === "string") outStr.update(value);
      if (typeof value === "number") outNum.update(value);
      if (typeof value === "boolean") outBoo.update(value);
    });
  });
  return { string: outStr, number: outNum, boolean: outBoo };
}

export function obsStrCond(
  funcArr: ((arg1: string) => string)[],
  f: (arg1: string) => boolean,
  o: Observable<string>
): Observable<string> {
  // TODO: Implement this function
  const r = new Observable<string>();
  o.subscribe(x => {
    let out = x;
    for (const f of funcArr) out = f(out);
    if (f(out)) r.update(out);
    else r.update(x);
  });
  return r;
}

export function statefulObserver(o: Observable<number>): Observable<number> {
  // TODO: Implement this function
  let prev = 0;
  const r: Observable<number> = new Observable<number>();
  o.subscribe(v => {
    if (v % prev === 0) {
      r.update(v);
    }
    prev = v;
  });
  return r;
}

// Optional Additional Practice

export function mergeMax(o1: Observable<number>, o2: Observable<number>): Observable<{ obs: number; v: number }> {
  // TODO: Implement this function
  let prevMax = -Infinity;
  const r = new Observable<{ obs: number; v: number }>();
  const f = (id: number) => (v: number) => {
    // f(id) is a closure receiving a value, possibly updating r
    if (v >= prevMax) {
      prevMax = v;
      r.update({ obs: id, v });
    }
  };
  o1.subscribe(f(1)); // closures subscribed to o1 and o2 are parameterized
  o2.subscribe(f(2)); // with ID of observable and share environment (prevMax)
  return r;
}

export function merge(o1: Observable<string>, o2: Observable<string>): Observable<string> {
  // TODO: Implement this function
  const r = new Observable<string>();
  const merger = (e: string) => {
    r.update(e);
  };
  o1.subscribe(merger);
  o2.subscribe(merger);
  return r;
}

export class GreaterAvgObservable extends Observable<number> {
  constructor() {
    super();
  }

  greaterAvg(): Observable<number> {
    // TODO: Implement this method
    const r = new Observable<number>();
    let prev = Infinity;
    let last = Infinity;
    this.subscribe(v => {
      if (v >= ((prev + last) * 3) / 4) {
        r.update(v);
      }
      prev = last;
      last = v;
    });
    return r;
  }
}

export class SignChangeObservable extends Observable<number> {
  constructor() {
    super();
  }

  signChange(): Observable<number> {
    // TODO: Implement this method
    const signChangeObservable = new Observable<number>();
    let prevSign = 0;

    this.subscribe((value: number) => {
      if ((value > 0 && prevSign <= 0) || (value < 0 && prevSign >= 0)) {
        signChangeObservable.update(value);
      }
      prevSign = Math.sign(value);
    });

    return signChangeObservable;
  }
}

/**
 * This function shows how the class you created above could be used.
 * @param numArr Array of numbers
 * @param f Observer function
 */
export function usingSignChange(numArr: number[], f: Observer<number>) {
  // TODO: Implement this function
  const sourceObservable = new SignChangeObservable();
  const signChangeObservable = sourceObservable.signChange();

  signChangeObservable.subscribe(f);

  for (const num of numArr) {
    sourceObservable.update(num);
  }
}
