import assert from "assert";
import { Color, COLORS, Image } from "../include/image.js";
import { imageMapCoord, imageMapIf, mapWindow, imageBlur, isGrayish, makeGrayish } from "./imageProcessingHOF.js";

// Helper function to check if a color is equal to another one with an error of 1 (default)
function expectColorToBeCloseTo(actual: Color, expected: Color, error = 1) {
  [0, 1, 2].forEach(i => expect(Math.abs(actual[i] - expected[i])).toBeLessThanOrEqual(error));
}

describe("imageMapCoord", () => {
  function identity(img: Image, x: number, y: number) {
    return img.getPixel(x, y);
  }

  it("should return a different image", () => {
    const input = Image.create(10, 10, COLORS.WHITE);
    const output = imageMapCoord(input, identity);
    assert(input !== output);
  });
  function changeToBlack(): Color {
    return [0, 0, 0];
  }
  it("should return a black image", () => {
    const input = Image.create(10, 10, COLORS.WHITE);
    const output = imageMapCoord(input, changeToBlack);
    for (let i = 0; i < 10; ++i)
      for (let j = 0; j < 10; ++j) {
        const p = output.getPixel(i, j);
        assert(p[0] === 0, "The red channel should be 0.");
        assert(p[1] === 0, "The green channel should be 0.");
        assert(p[2] === 0, "The blue channel should be 0.");
      }
    assert(input !== output);
  });
  // More tests for imageMapCoord go here.
});

describe("imageMapIf", () => {
  // More tests for imageMapIf go here
  it("should return a different image", () => {
    const input = Image.create(10, 10, COLORS.WHITE);
    expectColorToBeCloseTo(input.getPixel(0, 0), COLORS.WHITE);
    const condition = (img: Image, x: number, y: number) => {
      const pixel = img.getPixel(x, y);
      return pixel[0] === 255 && pixel[1] === 255 && pixel[2] === 255;
    };

    // Define a function that inverts colors
    const invertColor = () => [0, 0, 0];
    const output = imageMapIf(input, condition, invertColor);
    assert(input !== output);
    for (let i = 0; i < 10; ++i)
      for (let j = 0; j < 10; ++j) {
        const p = output.getPixel(i, j);
        assert(p[0] === 0, "The red channel should be 0.");
        assert(p[1] === 0, "The green channel should be 0.");
        assert(p[2] === 0, "The blue channel should be 0.");
      }
  });
});

describe("mapWindow", () => {
  it("should apply the given function to pixels within the specified window", () => {
    const input = Image.create(10, 10, COLORS.WHITE);
    const xInterval = [1, 4]; // x_min and x_max
    const yInterval = [1, 4]; // y_min and y_max

    const invertColor = () => [0, 0, 0];

    const output = mapWindow(input, xInterval, yInterval, invertColor);
    expectColorToBeCloseTo(output.getPixel(1, 1), COLORS.BLACK);
    expectColorToBeCloseTo(output.getPixel(2, 2), COLORS.BLACK);
    expectColorToBeCloseTo(output.getPixel(4, 4), COLORS.BLACK);
    expectColorToBeCloseTo(output.getPixel(3, 4), COLORS.BLACK);
    // More tests for mapWindow go here
  });
});

describe("isGrayish", () => {
  // More tests for isGrayish go here
  it("should return true", () => {
    const input = Image.create(10, 10, COLORS.BLACK);
    assert(isGrayish(input.getPixel(1, 1)));
  });
  it("should return false", () => {
    let input = Image.create(10, 10, COLORS.RED);
    assert(!isGrayish(input.getPixel(1, 1)));
    input = Image.create(10, 10, COLORS.GREEN);
    assert(!isGrayish(input.getPixel(1, 1)));
  });
});

describe("makeGrayish", () => {
  // More tests for makeGrayish go here
  const input = Image.create(10, 10, COLORS.GREEN);
  assert(!isGrayish(input.getPixel(1, 1)));
  const output = makeGrayish(input);
  assert(isGrayish(output.getPixel(1, 1)));
});

describe("pixelBlur", () => {
  // Tests for pixelBlur go here
  it("should apply a blur effect to each pixel in the image", () => {
    const input = Image.create(3, 3, COLORS.GREEN);

    const result = imageBlur(input);

    for (let y = 0; y < 3; y++) {
      for (let x = 0; x < 3; x++) {
        const originalPixel = input.getPixel(x, y);
        const blurredPixel = result.getPixel(x, y);
        expect(blurredPixel).toEqual(originalPixel);
      }
    }
  });
});

describe("imageBlur", () => {
  // Tests for imageBlur go here
  it("should apply a blur effect to each pixel in the image", () => {
    const input = Image.create(3, 3, COLORS.GREEN);

    // Act
    const result = imageBlur(input);

    // Assert
    for (let y = 0; y < 3; y++) {
      for (let x = 0; x < 3; x++) {
        const originalPixel = input.getPixel(x, y);
        const blurredPixel = result.getPixel(x, y);
        console.log(result.getPixel(x, y));
        expect(blurredPixel).toEqual(originalPixel);
      }
    }
  });
});
