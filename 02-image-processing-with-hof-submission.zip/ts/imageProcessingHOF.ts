import type { Image, Color } from "../include/image.js";

export function imageMapCoord(img: Image, func: (img: Image, x: number, y: number) => Color): Image {
  // TODO
  const a: Image = img.copy();
  for (let i = 0; i < img.width; i++) for (let j = 0; j < img.height; j++) a.setPixel(i, j, func(img, i, j));
  return a;
}

export function imageMapIf(
  img: Image,
  cond: (img: Image, x: number, y: number) => boolean,
  func: (p: Color) => Color
): Image {
  // TODO
  return imageMapCoord(img, (img, x, y) => (cond(img, x, y) ? func(img.getPixel(x, y)) : img.getPixel(x, y)));
}

export function mapWindow(
  img: Image,
  xInterval: number[], // Assumed to be a two element array containing [x_min, x_max]
  yInterval: number[], // Assumed to be a two element array containing [y_min, y_max]
  func: (p: Color) => Color
): Image {
  // TODO
  return imageMapIf(
    img,
    (img, x, y) => x >= xInterval[0] && x <= xInterval[1] && y >= yInterval[0] && y <= yInterval[1],
    x => func(x)
  );
}

export function isGrayish(p: Color): boolean {
  // TODO
  const maxValue = Math.max(p[0], p[1], p[2]);
  const minValue = Math.min(p[0], p[1], p[2]);

  return maxValue - minValue <= 85;
}
export function makeGrayish(img: Image): Image {
  return imageMapIf(
    img,
    (img, x, y) => !isGrayish(img.getPixel(x, y)),
    pixel => {
      const grayValue = Math.trunc((pixel[0] + pixel[1] + pixel[2]) / 3);
      return [grayValue, grayValue, grayValue];
    }
  );
}
function getAverageColor(pixels: Color[]): Color {
  const numPixels = pixels.length;
  let red = 0;
  let green = 0;
  let blue = 0;
  red = pixels.reduce((sum, e) => sum + e[0], 0);
  blue = pixels.reduce((sum, e) => sum + e[2], 0);
  green = pixels.reduce((sum, e) => sum + e[1], 0);

  red = Math.trunc(red / numPixels);
  green = Math.trunc(green / numPixels);
  blue = Math.trunc(blue / numPixels);

  return [red, green, blue];
}

export function pixelBlur(img: Image, x: number, y: number): Color {
  const neighbors = [];

  for (let xOffset = -1; xOffset <= 1; xOffset++) {
    for (let yOffset = -1; yOffset <= 1; yOffset++) {
      const neighborX = x + xOffset;
      const neighborY = y + yOffset;

      // Check if the neighbor coordinates are valid
      if (neighborX >= 0 && neighborX < img.width && neighborY >= 0 && neighborY < img.height) {
        const neighborPixel = img.getPixel(neighborX, neighborY);
        neighbors.push(neighborPixel);
      }
    }
  }
  const blurredColor = getAverageColor(neighbors);

  return blurredColor;
}

export function imageBlur(img: Image): Image {
  // TODO
  return imageMapCoord(img, pixelBlur);
}
