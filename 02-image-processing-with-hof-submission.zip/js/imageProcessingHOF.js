export function imageMapCoord(img, func) {
    // TODO
    const a = img.copy();
    for (let i = 0; i < img.width; i++)
        for (let j = 0; j < img.height; j++)
            a.setPixel(i, j, func(img, i, j));
    return a;
}
export function imageMapIf(img, cond, func) {
    // TODO
    return imageMapCoord(img, (img, x, y) => (cond(img, x, y) ? func(img.getPixel(x, y)) : img.getPixel(x, y)));
}
export function mapWindow(img, xInterval, // Assumed to be a two element array containing [x_min, x_max]
yInterval, // Assumed to be a two element array containing [y_min, y_max]
func) {
    // TODO
    return imageMapIf(img, (img, x, y) => x >= xInterval[0] && x <= xInterval[1] && y >= yInterval[0] && y <= yInterval[1], x => func(x));
}
export function isGrayish(p) {
    // TODO
    const maxValue = Math.max(p[0], p[1], p[2]);
    const minValue = Math.min(p[0], p[1], p[2]);
    return maxValue - minValue <= 85;
}
export function makeGrayish(img) {
    return imageMapIf(img, (img, x, y) => !isGrayish(img.getPixel(x, y)), pixel => {
        const grayValue = Math.trunc((pixel[0] + pixel[1] + pixel[2]) / 3);
        return [grayValue, grayValue, grayValue];
    });
}
function getAverageColor(pixels) {
    const numPixels = pixels.length;
    let red = 0;
    let green = 0;
    let blue = 0;
    red = pixels.reduce((sum, e) => sum + e[0], 0);
    blue = pixels.reduce((sum, e) => sum + e[2], 0);
    green = pixels.reduce((sum, e) => sum + e[1], 0);
    red = Math.trunc(red / numPixels);
    green = Math.trunc(green / numPixels);
    blue = Math.trunc(blue / numPixels);
    return [red, green, blue];
}
export function pixelBlur(img, x, y) {
    const neighbors = [];
    for (let xOffset = -1; xOffset <= 1; xOffset++) {
        for (let yOffset = -1; yOffset <= 1; yOffset++) {
            const neighborX = x + xOffset;
            const neighborY = y + yOffset;
            // Check if the neighbor coordinates are valid
            if (neighborX >= 0 && neighborX < img.width && neighborY >= 0 && neighborY < img.height) {
                const neighborPixel = img.getPixel(neighborX, neighborY);
                neighbors.push(neighborPixel);
            }
        }
    }
    const blurredColor = getAverageColor(neighbors);
    return blurredColor;
}
export function imageBlur(img) {
    // TODO
    return imageMapCoord(img, pixelBlur);
}
//# sourceMappingURL=imageProcessingHOF.js.map