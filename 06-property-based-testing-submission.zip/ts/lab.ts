import assert from "assert";
export function oracle(genArray: (num: number) => number[][]) {
  // TODO: Implement this function
  let n = Math.floor(Math.random() * 1000);
  let a = genArray(n);
  const valid = (x: number) => x % 1 === 0 && 0 <= x && x < n;
  function isPerm(p: number[]) {
    assert(p.length === n, "length n");
    assert(p.every(valid), "valid");
    const f = Array(n).fill(1);
    assert(
      p.every(e => --f[e] === 0),
      "no duplicates"
    );
  }
  assert(a.length === n, "a has n rows");
  a.forEach(isPerm);
  for (let k = 0; k < n; k++) isPerm(a.map(r => r[k]));
}
