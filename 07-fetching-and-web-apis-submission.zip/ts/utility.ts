// Even if you do not use this file, do not delete it. The autograder will fail.
export interface NameValuePair {
  name: string;
  value: string;
}

export function makeSearchURL(resource: string, parameters: NameValuePair[]): string {
  // Construct a new URL object using the resource URL
  const searchURL = new URL(resource);
  // Access the searchParams field of the constructed url
  // Add the sequence of parameters with values (@parmeters) to searchURL
  parameters.forEach(e => searchURL.searchParams.append(e.name, e.value));
  return searchURL.toString(); // Return the resulting complete URL
}
export function getTextfromURL(URL: string) {
  return fetch(URL).then(response => {
    if (response.ok) {
      return response.text();
    } else {
      throw new Error(`Failed to fetch text for "${URL}"`);
    }
  });
}
export function getJSONfromURL(URL: string) {
  return fetch(URL).then(response => {
    if (response.ok) {
      return response.json();
    } else {
      throw new Error(`Failed to fetch data for "${URL}"`);
    }
  });
}
