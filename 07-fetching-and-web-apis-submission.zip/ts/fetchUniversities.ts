import fetch from "../include/fetch.js";

export function fetchUniversities(query: string): Promise<string[]> {
  // TODO
  return fetch("http://220.maxkuechen.com/universities/search?name=" + query)
    .then(res => res.json())
    .then(json => {
      return Array.isArray(json) && json.length > 0
        ? Promise.resolve(
            json.map((uni: typeof Object) => {
              return uni.name;
            })
          )
        : Promise.reject([]);
    });
}
