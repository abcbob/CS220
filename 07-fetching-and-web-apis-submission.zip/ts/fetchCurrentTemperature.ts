import { GeoCoord } from "./fetchGeoCoord.js";
import { getJSONfromURL, makeSearchURL } from "./utility.js";
interface TemperatureReadingJSON {
  latitude: number;
  longitude: number;
  generationtime_ms: number;
  utc_offset_seconds: number;
  timezone: string;
  timezone_abbreviation: string;
  elevation: number;
  hourly_units: {
    time: string;
    temperature_2m: string;
  };
  hourly: TemperatureReading;
}
export interface TemperatureReading {
  time: string[];
  temperature_2m: number[];
}

export function fetchCurrentTemperature(coords: GeoCoord): Promise<TemperatureReading> {
  // TODO
  const parameters = [
    { name: "latitude", value: coords.lat.toString() },
    { name: "longitude", value: coords.lon.toString() },
    { name: "hourly", value: "temperature_2m" },
    { name: "temperature_unit", value: "fahrenheit" },
  ];
  const resource = "https://220.maxkuechen.com/currentTemperature/forecast";

  return getJSONfromURL(makeSearchURL(resource, parameters)).then((data: TemperatureReadingJSON) => {
    const result = {
      time: data.hourly.time,
      temperature_2m: data.hourly.temperature_2m,
    };
    return result;
  });
}
