import fetch from "../include/fetch.js";
export function fetchGeoCoord(query) {
    // TODO
    return new Promise((resolve, reject) => {
        fetch("https://220.maxkuechen.com/geoCoord/search?q=" + query)
            .then(response => {
            if (!response.ok) {
                throw new Error("No results found for query.");
            }
            return response.json();
        })
            .then((data) => {
            if (data.length > 0) {
                const firstResult = {
                    lat: Number.parseFloat(data[0]["lat"].toString()),
                    lon: Number.parseFloat(data[0]["lon"].toString()),
                };
                resolve(firstResult);
            }
            else
                reject(new Error("No results found for query."));
        })
            .catch(error => {
            reject(error);
        });
    });
}
//# sourceMappingURL=fetchGeoCoord.js.map