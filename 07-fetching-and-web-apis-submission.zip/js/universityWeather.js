import { fetchUniversities } from "./fetchUniversities.js";
import { fetchGeoCoord } from "./fetchGeoCoord.js";
import { fetchCurrentTemperature } from "./fetchCurrentTemperature.js";
export function fetchUniversityWeather(universityQuery, transformName) {
    //Variables are made to be used as storage for derived values in then, to be used by result in the end
    const names = [];
    const temps = [];
    return fetchUniversities(universityQuery)
        .then(res => {
        const rL = res.length;
        if (rL === 0) {
            return Promise.reject(new Error("No results found for query."));
        }
        else {
            return Promise.resolve(res.map(uni => {
                names.push(uni);
                if (transformName !== undefined)
                    uni = transformName(uni);
                return fetchGeoCoord(uni);
            }));
        }
    })
        .then(res => {
        return Promise.resolve(res.map(coord => coord.then(c => fetchCurrentTemperature(c))));
    })
        .then(async (res) => {
        const arrayOfCurrentTemp = res.map(reading => {
            return reading.then(temp => {
                const currentDate = new Date();
                const timestamp = currentDate.getHours();
                const t = temp["temperature_2m"][timestamp + 5]; // ISSUE: Is the current tempature stored in the first element?
                temps.push(t);
                return t;
            });
        });
        return await Promise.all(arrayOfCurrentTemp) //array holds Promises of numbers, once all done we add to averge through reduce
            .then(() => {
            const avg = temps.reduce((acc, curr) => acc + curr, 0);
            const len = temps.length;
            console.log(names, temps);
            const result = { totalAverage: avg / len };
            for (let i = 0; i < len; i++) {
                // We now have an array of names and correspodnign temps, and we can add each to resulting object
                // Object.defineProperty(result,names[i],temps[i]);
                result[names[i]] = temps[i];
            }
            return result;
        });
    });
}
export function fetchUMassWeather() {
    // TODO
    function makeString(s) {
        return s.replace("at ", "");
    }
    return fetchUniversityWeather("University of Massachusetts", makeString);
}
export function fetchUCalWeather() {
    // TODO
    function makeString(s) {
        return s.replace("at ", "");
    }
    return fetchUniversityWeather("University of California", makeString);
}
//# sourceMappingURL=universityWeather.js.map