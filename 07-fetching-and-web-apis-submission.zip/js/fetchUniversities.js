import fetch from "../include/fetch.js";
export function fetchUniversities(query) {
    // TODO
    return fetch("http://220.maxkuechen.com/universities/search?name=" + query)
        .then(res => res.json())
        .then(json => {
        return Array.isArray(json) && json.length > 0
            ? Promise.resolve(json.map((uni) => {
                return uni.name;
            }))
            : Promise.reject([]);
    });
}
//# sourceMappingURL=fetchUniversities.js.map