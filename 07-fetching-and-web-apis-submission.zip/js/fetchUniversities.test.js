import assert from "assert";
import { fetchUniversities } from "./fetchUniversities.js";
describe("fetchUniversities", () => {
    it("follows type specification", () => {
        const promise = fetchUniversities("University of Massachusetts at Amherst");
        return promise.then(result => {
            assert(Array.isArray(result)); // Assert the result in an array
            assert(result.every(x => typeof x === "string")); // Assert each element in the array is a string
            assert(result[0] === "University of Massachusetts at Amherst");
        });
    });
    it("Fetchs the correct schools", () => {
        const promise = fetchUniversities("Amherst");
        return promise.then(result => {
            assert(Array.isArray(result)); // Assert the result in an array
            assert(result.every(x => typeof x === "string")); // Assert each element in the array is a string
            assert(result.length === 2);
            assert(result[1] === "University of Massachusetts at Amherst");
            assert(result[0] === "Amherst College");
        });
    });
    it("Url fetch reject properly", () => {
        const promise = fetchUniversities("Amhersty");
        return promise.catch((result) => {
            assert(result.length === 0);
        });
    });
});
//# sourceMappingURL=fetchUniversities.test.js.map