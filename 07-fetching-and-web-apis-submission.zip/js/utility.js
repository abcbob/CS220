export function makeSearchURL(resource, parameters) {
    // Construct a new URL object using the resource URL
    const searchURL = new URL(resource);
    // Access the searchParams field of the constructed url
    // Add the sequence of parameters with values (@parmeters) to searchURL
    parameters.forEach(e => searchURL.searchParams.append(e.name, e.value));
    return searchURL.toString(); // Return the resulting complete URL
}
export function getTextfromURL(URL) {
    return fetch(URL).then(response => {
        if (response.ok) {
            return response.text();
        }
        else {
            throw new Error(`Failed to fetch text for "${URL}"`);
        }
    });
}
export function getJSONfromURL(URL) {
    return fetch(URL).then(response => {
        if (response.ok) {
            return response.json();
        }
        else {
            throw new Error(`Failed to fetch data for "${URL}"`);
        }
    });
}
//# sourceMappingURL=utility.js.map