import { getTextfromURL, getJSONfromURL } from "./utility.js";
import * as readline from "node:readline/promises";
import { stdin as input, stdout as output } from "node:process";
/* This program takes in 2 APIs: http://numbersapi.com/ and https://api.worldbank.org/
This returns the current date and returns 1 random fact about what happened during that day.
It also returns some random facts the date itself, including the day and month.
(e.g:Today is 01/01, on 01/01/2004, A happened, and 01 is the first odd natural number)
After that, it asks the user to give in an input of a number
The program will output another fact about the number, as well as 1 of the topics listed by the World Bank Group*/
const day = new Date().getDate();
const month = new Date().getMonth();
const year = new Date().getFullYear();
const topic = "trivia";
console.log("Today is " + month + "/" + day);
await getTextfromURL("http://numbersapi.com/" + day + "/" + topic).then(console.log);
if (day != month)
    await getTextfromURL("http://numbersapi.com/" + month + "/" + topic).then(console.log);
await getTextfromURL("http://numbersapi.com/" + month + "/" + day + "/date").then(console.log);
console.log("----------------------------------------");
const rl = readline.createInterface({ input, output });
const answer = await rl.question("What number are you thinking? ");
const out = parseInt(answer);
if (typeof out === "number") {
    await getTextfromURL("http://numbersapi.com/" + out + "/math").then(console.log);
    console.log("----------------------------------------");
    console.log("Here is something interesting based on your answer:");
    await getJSONfromURL("http://api.worldbank.org/v2/topic/?format=JSON").then(data => {
        if (data.length > 0) {
            const out = {
                res: data[1][Math.abs(parseInt(answer) - 1) % 21],
            };
            console.log(out.res);
        }
    });
}
else
    console.log("Should have given a number :(");
rl.close();
//# sourceMappingURL=main.js.map